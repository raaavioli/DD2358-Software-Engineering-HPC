#ifndef __MATRIX_H__
#define __MATRIX_H__

void gemm(int, double*, double*, double*);

#endif
